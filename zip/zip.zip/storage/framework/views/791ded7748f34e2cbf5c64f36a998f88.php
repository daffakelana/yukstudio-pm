<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\daffa-putra\code-source\yuk-studio-project-management\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>